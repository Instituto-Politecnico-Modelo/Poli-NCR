XSETUPPATH="/etc/X11/xdm"
XINITRCPATH="/etc/X11/xinit"

# we will ensure there is always a backup
backupXsetup()
{
	CURRENTNUM=1
	VALIDFILE=0
	while [ $VALIDFILE = "0" ]; do
		if [ ! -f "${XSETUPPATH}/Xsetup.backup${CURRENTNUM}" ]; then
			cp -fv ${XSETUPPATH}/Xsetup ${XSETUPPATH}/Xsetup.backup${CURRENTNUM}
			VALIDFILE=1
		else
			CURRENTNUM=$((CURRENTNUM+1))
		fi
	done
}

removeFromXsetup()
{
	backupXsetup
	sed -e '/# TSHARCCONFIGSTART/,/TSHARCCONFIGEND/d' ${XSETUPPATH}/Xsetup >${XSETUPPATH}/Xsetupnew
	cp -fv ${XSETUPPATH}/Xsetupnew ${XSETUPPATH}/Xsetup
}

# we will ensure there is always a backup
backupxinitrc()
{
	CURRENTNUM=1
	VALIDFILE=0
	while [ $VALIDFILE = "0" ]; do
		if [ ! -f "${XINITRCPATH}/xinitrc.backup${CURRENTNUM}" ]; 
		then
			cp -fv ${XINITRCPATH}/xinitrc ${XINITRCPATH}/xinitrc.backup${CURRENTNUM}
			VALIDFILE=1
		else
			CURRENTNUM=$((CURRENTNUM + 1))
		fi
	done
}

removeFromxinitrc()
{
	backupxinitrc
	sed -e '/# TSHARCCONFIGSTART/,/TSHARCCONFIGEND/d' ${XINITRCPATH}/xinitrc >${XINITRCPATH}/xinitrcnew
	cp -fv ${XINITRCPATH}/xinitrcnew ${XINITRCPATH}/xinitrc
}

removeFromXsetup
removeFromxinitrc