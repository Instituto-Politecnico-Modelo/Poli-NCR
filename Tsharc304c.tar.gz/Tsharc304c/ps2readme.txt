Hampshire TSHARC PS/2 Linux driver kernel configuration steps

Revision: 3.0.5 BETA

Date: December 4, 2007

**********************************************************************************
If the TSHARC installation script gave a "serio_raw component not found" please follow the below procedure.  Otherwise, this procedure should not be necessary.

**********************************************************************************
This document is divided into the following sections:
I.    System Requirements
II.   Including the required components into the kernel

**********************************************************************************
I.  System Requirements
	- Kernel version 2.4.x or
	- Kernel version 2.6.9 or above

If the TSHARC installation script gave a "serio_raw component not found" please follow the below procedure.  Otherwise, this procedure should not be necessary.

Note: There has been issues seen with attaining raw access to the PS/2 port using this procedure on approximately 2.6.19 kernels and above.

**********************************************************************************
II. Including the required components into the kernel

1> Download the kernel source for the current kernel version or any kernel source code version 2.6.9 or newer.  If possible, use the kernel source that comes with your distribution.

2> Log into system as root or enter "su" at the command prompt.

3> Extract the source code to a directory under "/usr/src".

4> Change the current directory to where the kernel source code was extracted.

5> Enter "make menuconfig" at the command prompt.

6> Selected the "Provide legacy /dev/psaux device" and "Raw access to serio ports" items found somewhere under "Device Driver->Input device support" (this location in the menu sometimes varies between kernel versions).  It is recommended that an asterisk be placed to the left of SERIO and an 'M' to the left of SERIO_RAW.

7> Exit and save the current configuration.

Note: You may wish to choose different varations on steps 8, 9, and 10 depending on your system configuration.

8> Enter "make" at the command prompt.

9> Enter "make modules_install" at the command prompt.

Note: If the kernel source is for the current version of the kernel and SERIO_RAW was selected as a module in step 6, then step 10 can be skipped.
10> Enter "make install" at the command prompt.

The "make install" usually automatically adds a grub (or lilo) menu item on most newer kernel versions.  However, if this does not correctly modify the grub menu  configuration, the "menu.lst", lilo.conf or "grub.conf" file may need to be modified appropriately.

**********************************************************************************

Your system should now be correctly setup.  Now, please run installation script.
