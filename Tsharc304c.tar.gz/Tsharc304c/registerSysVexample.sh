#!/bin/bash
CONFIGDIRECTORY="/etc/tsharc"
VERSION="3.0.4b"
echo "Please enter root directory path of SysV initialization scripts:"
read DAEMONINIT

#echo "Add links to start daemon under runlevel 5"
#if [ -d "${DAEMONINIT}/rc5.d" ]; then
#	ln -sf "${CONFIGDIRECTORY}/boot.tsharc" "${DAEMONINIT}/rc5.d/S10boot.tsharc"
#	ln -sf "${CONFIGDIRECTORY}/boot.tsharc" "${DAEMONINIT}/rc5.d/K10boot.tsharc"
#fi

#echo "Add links to start daemon under runlevel 4"
#if [ -d "${DAEMONINIT}/rc3.d" ]; then
#	ln -sf "${CONFIGDIRECTORY}/boot.tsharc" "${DAEMONINIT}/rc3.d/S10boot.tsharc"
#	ln -sf "${CONFIGDIRECTORY}/boot.tsharc" "${DAEMONINIT}/rc3.d/K10boot.tsharc"
#fi

echo "Add links to start daemon under all run levels"
if [ -d "${DAEMONINIT}/rcS.d" ]; then
        ln -sf "${DAEMONINIT}/boot.tsharc" "${DAEMONINIT}/rcS.d/S10boot.tsharc"
        ln -sf "${DAEMONINIT}/boot.tsharc" "${DAEMONINIT}/rcS.d/K10boot.tsharc"
        ln -sf "${CONFIGDIRECTORY}/boot.tsharc" "${DAEMONINIT}/boot.tsharc"
fi

# this part seems to be Suse specific
if [ -x "/sbin/insserv" ]; then
	echo "Registering Daemon with system"
	/sbin/insserv boot.tsharc
fi

echo "Creating unregisterSysV script"

echo '#!/bin/sh' > ./unregisterSysVheader	

echo "DAEMONINIT=\"${DAEMONINIT}\"" >> ./unregisterSysVheader
echo "VERSION=\"${VERSION}\"" >> ./unregisterSysVheader

cat ./unregisterSysVbase >> unregisterSysVheader
cp -f unregisterSysVheader unregisterSysV.sh
chmod 755 unregisterSysV.sh
rm ./unregisterSysVheader

cp ./unregisterSysV.sh /usr/bin
